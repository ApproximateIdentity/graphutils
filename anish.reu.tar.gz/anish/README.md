Anish King
Gilad Penn

to install dependences, please visit http://mojolicio.us/ for mojolicious

To view the results:
in the terminal - 
go to root directory
run:
	
	 ./myapp.pl daemon go to 127.0.0.1:3000
	 
to create/view results, open your browser and type:
	
	localhost:3000

type in either 1 2 or 3. these refer to graph files
this calls a eigen function, which will run alogirhtms 
on these graphs and return the results which will
be rendered by the perl server.  some of the perl functions
call c++ functions, compiling and executing the c++ code
using the `` notation