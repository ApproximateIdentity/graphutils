#include <fstream>
#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

int main(int argc, const char * argv[]) {
	// std::cout << "test\n";
    // Uses the first command line arg as the file name
    ifstream f(argv[1]);
    string line;
    // Read each line and print it
    int i = 0; // Initialize i, j, k to start count process
    int j = 0;
    while (getline(f, line)) {
        j++;
        i = j / 2;
    }
     /* Declare variable dim, to count the number of nodes 
	- or dimension, of the square matrix */
    int dim = i;
    printf ("%i\n", dim);
	// find the file length
	// set a var = to file length
    return dim;
}