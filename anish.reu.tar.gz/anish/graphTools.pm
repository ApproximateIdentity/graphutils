#!/usr/bin/perl

# Anish King and Gilad Penn
# graphTools.pl
# This program cuts a graph using eigenvector
# Input: 
# Undirected graph G (from .txt file)
# Outputs:
# 1. the file read in
# 2. the number of nodes in the undirected graph
# 3. the adjacency matrix
# 4. the degree matrix
# 5. the DminusHalf matrix

package graphTools;
use strict;
use warnings;
use Exporter qw(import);
our @EXPORT_OK = qw(getEigen);

sub getEigen {
	my $graph = $_[0];
	my $filename = "graph" . $graph . ".txt";
	my $file = getFile($filename);
	my $count = countNodes($filename);
	# essentially you receive a reference from the function
	# hence the "$" notation for the matrix refence
	(my $matrixRef, my $dim) = adjacencyMatrix($file);
	my $diagonalRef = getDiagonal($matrixRef, $count, $dim);
	my $dExpRef = getDExp($diagonalRef, $count);
	# pass the varaibles and the matrix refences back
	return ($file, $count, $matrixRef, $diagonalRef, $dExpRef);
}

# reads in the file using cpp code
sub getFile {
	my $filename = $_[0];
	# I/O, load the graph .txt file
	# Compile the c++ io file
	`g++ io.cpp -o io.o`;
	# Read the graph file into an array
	# Uses the c++ code
	my $file = `./io.o $filename`;
	# present the data in a user friendly manner
	return $file;
}

# countNodes returns $dim, the number of vertices/nodes in the graph
# cpp code is used
sub countNodes {
	my $filename = $_[0];
	# Compile the c++ dimNodes io file
	`g++ countNodes.cpp -o countNodes.o`;
	my $dim = `./countNodes.o $filename`;	
	return $dim;
}

# adjacencyMatrix function takes in an input directed graph G
# and outputs its adjacency matrix of 1's and 0's
sub adjacencyMatrix {
	my $file = $_[0];
	my @file = split "\n", $file;

	my @values;
	for (my $i = 0; $i < @file.length; $i++) {
		# Skip a line (to dim nodes)
		if($i % 2) {
			# Save the value at that line in @values
			push(@values, $file[$i]); 
		}
	}
	# determine size of our matrix
	my $size =  scalar @file/2;
	# our $matrix is global so we can pass into other functions
	my @matrix;

	for (my $i = 0; $i < $size; $i++) {
		my $line = $values[$i];
		# @line is an array of the values, split by spaces
		my @line = split(' ', $line);
		# matrix is square, so iterate through size of values
		for (my $j = 0; $j < $size; $j++) {
			# if j is one of the node connections 
			if (grep $_ eq $j, @line) {
				$matrix[$i][$j] = 1;
			} else {
				$matrix[$i][$j] = 0;
			}	
		}
	}
	# Initialize and set $dime, the number of nodes
	my $count = @values.length;

	# Return a reference the adjacency matrix and the number of nodes
	return (\@matrix , $count);
}

# getDiagonal creates a diagonal matrix using the adjacency matrix
# and countNodes $dim
sub getDiagonal {
	my $matrixRef = $_[0]; 
	# deReference the matrix 
	my @matrix = @$matrixRef;
	my $count = $_[1];
	my $dim = $_[2];
	my @d;
	
	for (my $i = 0; $i < $count; $i++) {
		my @row;
		my $deg = 0;
		for (my $k = 0; $k < $dim; $k++) {
			push(@row, 0);		
		}
		for (my $j = 0; $j < $dim; $j++) {
			$deg += $matrix[$i][$j];
		}
		$row[$i] = $deg;
		# push the row reference into the matrix
		push(@d, \@row);
	}
	# return a reference to the actual degree matrix
	return \@d;
}

# getDExp returns the diagonal matrix to the power of negative 1/2.
sub getDExp {
	my $diagonalRef = $_[0];
	# dereference the diagonal matrix
	my @diagonal = @$diagonalRef;
	my $count = $_[1];
	# since the matrix contains references to the row arrays
	# we don't want to change them with this function
	# rather return a completely new matrix
	# hence, make a pseudo-deepcopy of the original
	my @diag = map { [@$_] } @diagonal;
	
	for (my $i = 0; $i < $count; $i++) {
		$diag[$i][$i] = $diag[$i][$i] ** -.5;
	}
	# return a reference to the d minus half matrix
	return \@diag;
}

1;