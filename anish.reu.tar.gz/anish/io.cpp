#include <fstream>
#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {

    // Uses the first command line arg as the file name
    ifstream f(argv[1]);
    string line;
    // Read each line and print it
    while (getline(f, line)) {
        cout << line << "\n";
    } 
}