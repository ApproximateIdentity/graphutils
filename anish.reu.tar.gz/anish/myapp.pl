#!/usr/bin/env perl 
use Mojolicious::Lite;
use strict;

use graphTools qw(getEigen);

get '/' => 'index';

get '/eigen' => sub {
    my $self = shift;
    my $graph = $self->param('graph'); 
    my ($file, $count, $matrix, $diagonal, $dExp) = getEigen($graph);
    $self->stash( graph => $graph, file => $file, count => $count, matrix => $matrix, diagonal => $diagonal, dExp => $dExp);

} => 'eigen';

app->start;

__DATA__

@@ index.html.ep
<form name="input" action="/eigen" method="get">
Name of graph: <input type="text" name="graph">
<input type="submit" value="Submit">
</form>
<p>e.g. 1, 2, or 3</p>
@@ eigen.html.ep
<p>graph: <%= $graph %></p>

<p>file contents: </p>
% my @file = split "\n", $file;
% foreach my $row (@file) {
  <p style="line-height:50%"><%= $row %></p>
% }

<p>number of nodes: <%= $count %></p>

<p>matrix:</p>
<table style="width:300px">
% foreach my $row (@$matrix) {
  <tr>
  % foreach my $column (@$row) {
    <td><%= $column %></td> 
  % }
  </tr>
% }
</table>

<p>diagonal matrix:</p>
<table style="width:300px">
% foreach my $row (@$diagonal) {
  <tr>
  % foreach my $column (@$row) {
    <td><%= $column %></td> 
  % }
  </tr>
% }
</table>

<p>dExp matrix:</p>
<table style="width:300px">
% foreach my $row (@$dExp) {
  <tr>
  % foreach my $column (@$row) {
    % if($column != 0) { 
    <td><%= sprintf("%.3f", $column);  %></td> 
    % } else {
      <td><%= sprintf("0");  %></td> 
    % }
  % }
  </tr>
% }
</table>
